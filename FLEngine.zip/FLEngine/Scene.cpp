#include "Scene.h"
#include "Precompiled.h"


Scene::Scene()
{
}


Scene::~Scene()
{
}
