#pragma once

class ComponentBase
{
public:
	ComponentBase();
	~ComponentBase();
};

