#include "ComponentBase.h"



ComponentBase::ComponentBase()
{
}


ComponentBase::~ComponentBase()
{
}
