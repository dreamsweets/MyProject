#include "System.h"



System::System()
{
}


System::~System()
{
}
