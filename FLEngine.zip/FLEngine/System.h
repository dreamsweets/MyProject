#pragma once
class System
{
public:
	System();
	~System();
};

